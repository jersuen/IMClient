package com.jersuen.im;

import android.app.Application;

/**
 * Created by JerSuen on 14-5-4.
 */
public class IM extends Application {
}
